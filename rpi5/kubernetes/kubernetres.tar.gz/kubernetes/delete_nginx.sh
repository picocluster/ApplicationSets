kubectl delete deployment nginx
kubectl delete endpoints nginx
kubectl delete service nginx
