microk8s.kubectl delete deployment nginx
microk8s.kubectl delete endpoints nginx
microk8s.kubectl delete service nginx
